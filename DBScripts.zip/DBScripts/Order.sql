
Order

* sudo -i -u postgres 
Give password for ubuntu user of this lap
* psql 
* CREATE USER order_user WITH PASSWORD 'order_password';
* \q
* psql -d ecommerce
* CREATE SCHEMA order_service AUTHORIZATION order_user;
* \dn
           List of schemas
       Name        |       Owner       
-------------------+-------------------
 customer_service  | customer_user
 inventory_service | inventory_user
 order_service     | order_user
 payment_service   | payment_user
 product_catalog   | product_user
 public            | pg_database_owner
(6 rows)


* ALTER SCHEMA order_service OWNER TO order_user;
* GRANT USAGE ON SCHEMA order_service TO order_user;
* ALTER DEFAULT PRIVILEGES IN SCHEMA order_service GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO order_user;
******* ALTER DEFAULT PRIVILEGES IN SCHEMA customer_service GRANT SELECT ON TABLES TO customer_user;
* CREATE TABLE order_service.orders (
    order_id VARCHAR PRIMARY KEY,
    customer_id VARCHAR NOT NULL,
    product_id VARCHAR NOT NULL,
    quantity INTEGER,
    order_status VARCHAR
);

* INSERT INTO order_service.orders (order_id, customer_id, product_id, quantity, order_status) 
VALUES 
('OD001', 'C001', 'P001', 10, 'Pending'),
('OD002', 'C001', 'P001', 5, 'Pending'),
('OD003', 'C001', 'P002', 3, 'Pending');



