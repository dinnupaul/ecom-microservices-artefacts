
Customer
* sudo -i -u postgres 
Give password for ubuntu user of this lap
* psql 
* CREATE USER customer_user WITH PASSWORD 'customer_password';
* \q
* psql -d ecommerce
* CREATE SCHEMA customer_service AUTHORIZATION customer_user;
* \dn
  List of schemas
       Name       |       Owner       
------------------+-------------------
 customer_service | customer_user
 product_catalog  | product_user
 public           | pg_database_owner
(3 rows)

* ALTER SCHEMA customer_service OWNER TO customer_user;
* GRANT USAGE ON SCHEMA customer_service TO customer_user;
* ALTER DEFAULT PRIVILEGES IN SCHEMA customer_service GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO customer_user;
******* ALTER DEFAULT PRIVILEGES IN SCHEMA customer_service GRANT SELECT ON TABLES TO customer_user;
* CREATE TABLE customer_service.customers (
    customer_id VARCHAR PRIMARY KEY,
    name VARCHAR NOT NULL,
    email VARCHAR UNIQUE NOT NULL,
    phone VARCHAR,
    address VARCHAR
);

* INSERT INTO customer_service.customers (customer_id, name, email, phone, address) 
VALUES 
('C001', 'John Doe', 'john.doe@example.com', '1234567890', '123 Main St'),
('C002', 'Jane Smith', 'jane.smith@example.com', '0987654321', '456 Elm St'),
('C003', 'Alice Brown', 'alice.brown@example.com', '1122334455', '789 Oak St');



