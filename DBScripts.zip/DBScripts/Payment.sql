
Payment
* sudo -i -u postgres 
Give password for ubuntu user of this lap
* psql 
* CREATE USER payment_user WITH PASSWORD 'payment_password';
* \q
* psql -d ecommerce
* CREATE SCHEMA payment_service AUTHORIZATION payment_user;
* \dn
   Name        |       Owner       
-------------------+-------------------
 customer_service  | customer_user
 inventory_service | inventory_user
 payment_service   | payment_user
 product_catalog   | product_user
 public            | pg_database_owner

(3 rows)

* ALTER SCHEMA payment_service OWNER TO payment_user;
* GRANT USAGE ON SCHEMA payment_service TO payment_user;
* ALTER DEFAULT PRIVILEGES IN SCHEMA payment_service GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO payment_user;
* -- Create Payment Table
CREATE TABLE payment_service.payment (
    payment_id VARCHAR PRIMARY KEY,
    customer_id VARCHAR NOT NULL,
    order_id VARCHAR NOT NULL,
    amount INTEGER NOT NULL,
    payment_status VARCHAR NOT NULL, -- e.g., 'SUCCESS', 'FAILED', 'PENDING'
    payment_method VARCHAR NOT NULL, -- e.g., 'CREDIT_CARD', 'PAYPAL', 'COD'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


* -- Insert Payment Records
INSERT INTO payment_service.payment (payment_id, customer_id, order_id, amount, payment_status, payment_method)
VALUES
    ('PAY001', 'C001', 'O001', 1500, 'SUCCESS', 'CREDIT_CARD'),
    ('PAY002', 'C002', 'O002', 200, 'PENDING', 'PAYPAL');




