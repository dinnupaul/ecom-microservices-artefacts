
Product catalog
* sudo -i -u postgres 
Give password for ubuntu user of this lap
* psql
* CREATE DATABASE ecommerce;
* CREATE USER product_user WITH PASSWORD 'product_password';
* \q
* psql -d ecommerce
* CREATE SCHEMA product_catalog AUTHORIZATION product_user;
* \dn
 List of schemas
      Name       |       Owner       
-----------------+-------------------
 product_catalog | product_user
 public          | pg_database_owner
(2 rows)

* ALTER SCHEMA product_catalog OWNER TO product_user;
* GRANT USAGE ON SCHEMA product_catalog TO product_user;
* ALTER DEFAULT PRIVILEGES IN SCHEMA product_catalog GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO product_user;
* CREATE TABLE product_catalog.products (
    product_id VARCHAR PRIMARY KEY,
    name VARCHAR NOT NULL,
    description VARCHAR,
    price INTEGER NOT NULL
);
* INSERT INTO product_catalog.products (product_id, name, description, price) 
VALUES 
('P001', 'Laptop', 'High-performance laptop', 1000),
('P002', 'Mouse', 'Wireless optical mouse', 20),
('P003', 'Keyboard', 'Mechanical keyboard', 50);

{
    "productid":"P004",
    "productname":"Mobile Phone",
    "description":"Vivo V 40",
    "price":30000

}


