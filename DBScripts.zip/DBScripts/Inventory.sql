
Inventory
* sudo -i -u postgres 
Give password for ubuntu user of this lap
* psql 
* CREATE USER inventory_user WITH PASSWORD 'inventory_password';
* \q
* psql -d ecommerce
* CREATE SCHEMA inventory_service AUTHORIZATION inventory_user;
* \dn
   Name        |       Owner       
-------------------+-------------------
 customer_service  | customer_user
 inventory_service | inventory_user
 product_catalog   | product_user
 public            | pg_database_owner

(3 rows)

* ALTER SCHEMA inventory_service OWNER TO inventory_user;
* GRANT USAGE ON SCHEMA inventory_service TO inventory_user;
* ALTER DEFAULT PRIVILEGES IN SCHEMA inventory_service GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO inventory_user;
* CREATE TABLE inventory_service.inventory (
    product_id VARCHAR PRIMARY KEY,
    quantity INTEGER NOT NULL
);

* INSERT INTO inventory_service.inventory (product_id, quantity) 
VALUES 
( 'P001', 50),
( 'P002', 100),
( 'P003', 75);




